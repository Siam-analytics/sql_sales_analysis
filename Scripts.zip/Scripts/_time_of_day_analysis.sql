-- Sales Distribution: Item Categories by Time Period
SELECT 
    COUNT(order_id) total_orders, item_type, 
    time_of_sale
FROM
    food
GROUP BY item_type , time_of_sale
ORDER BY item_type , total_orders DESC ;