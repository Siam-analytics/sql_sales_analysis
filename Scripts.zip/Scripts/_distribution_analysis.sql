-- Popularity of item among different customers
SELECT 
    received_by,
    item_name, 
    SUM(quantity) AS total_bought
FROM
    food
GROUP BY received_by , item_name
ORDER BY received_by , SUM(quantity) DESC ;
