-- Seasonal Sales of each item
WITH seasonal_segmentation as (
SELECT 
	item_name, 
	transaction_amount, 
	CASE WHEN month(date) = 2 THEN 'spring'
		WHEN month(date) between 3 and 5 THEN 'summer'
		WHEN month(date) between  6 and 9 THEN 'Monsoon'
		WHEN month(date) between 10 and 11 THEN 'Pre-Winter'
	ELSE 'Winter'
	END AS season
FROM food
ORDER BY item_name DESC 
)

SELECT item_name, season, sum(transaction_amount) AS total_amount
FROM seasonal_segmentation
group by item_name, season
order by item_name, total_amount DESC;

