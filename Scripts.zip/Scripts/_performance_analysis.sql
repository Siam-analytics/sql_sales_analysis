-- Monthly Item Performance: Sales vs. Annual Average with Performance Flag
WITH monthly_total_amount AS (
SELECT 
	item_name, 
	YEAR(date) as year, 
	MONTH(date) as month, 
	SUM(transaction_amount) as total_amount
FROM food
GROUP BY year(date), month(date), item_name
ORDER BY year, item_name
)
SELECT 
	*, 
	ROUND(AVG(total_amount) OVER(partition by item_name, year),2) as monthly_avg, 
	total_amount-round(AVG(total_amount) OVER(partition by item_name, year),2) as avg_diff,
CASE WHEN total_amount-round(AVG(total_amount) OVER(partition by item_name, year),2)<0 THEN 'bad'
     WHEN total_amount-round(AVG(total_amount) OVER(partition by item_name, year),2)=0 THEN 'avg'
     WHEN total_amount-round(AVG(total_amount) OVER(partition by item_name, year),2)>0 THEN 'good'
END AS sales_perf
FROM monthly_total_amount ;
