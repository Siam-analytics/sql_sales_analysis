-- Performace of each item over the years
WITH cte1 as (
SELECT 
	YEAR (date) as year, item_name, SUM (quantity) AS total_sales
FROM food
GROUP BY YEAR (date), item_name
ORDER BY YEAR (date), total_sales DESC
)

SELECT  
	*, 
	SUM(total_sales) OVER (partition by year) as total_yearly_sales, 
	CONCAT((total_sales/sum(total_sales) over(partition by year)*100), ' %')
	AS total_yearly_sales
FROM cte1 ;
 