-- What is the best payout method?
SELECT 
    transaction_type, COUNT(transaction_type) as total
FROM
    food
GROUP BY transaction_type
ORDER BY total DESC ;
