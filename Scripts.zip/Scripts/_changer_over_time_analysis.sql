-- Monthly sales_amount
SELECT 
    YEAR(date) AS year,
    MONTH(date) AS month,
    SUM(transaction_amount) AS sales_amount
FROM
    food
GROUP BY YEAR(date) , MONTH(date)
ORDER BY YEAR(date) , MONTH(date) ;