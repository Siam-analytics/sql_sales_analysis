-- Key matrices
SELECT 
    SUM(transaction_amount) AS total_sales
FROM
    food ;

SELECT 
    SUM(quantity) AS total_sold
FROM
    food ;

SELECT 
    COUNT(order_id) AS total_orders
FROM
    food ;
